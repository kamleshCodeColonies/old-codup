import Breadcumb from "@/src/components/Breadcumb";
import Layout from "@/src/layout/Layout";
const PortfolioDetails = () => {
  return (
    <Layout>
      <Breadcumb pageName={"Finance Manager"} title={"Finance Division"} />
      <div className="case-study-details">
        <div className="container">
          <div className="case-study-intro">
            <div className="row align-items-center">
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-thumb">
                  <img
                    src="assets/images/resource/portfolio-details.jpg"
                    alt="thumb"
                  />
                </div>
              </div>
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-info">
                  <div className="csd-title pt-30 mb-4">
                    <h3>Job Overviews</h3>
                  </div>
                  <ul>
                    <li>
                      <strong>Location</strong> <span>Ahmedabad </span>{" "}
                    </li>
                    <li>
                      <strong>Job Title</strong> <span>Finance Manager</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Hours </strong>{" "}
                      <span>8h / day (5 days working)</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Mail Your Resume </strong>{" "}
                      <span style={{ textTransform: "lowercase" }}>
                        hr@codup.tech
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="case-study-intro upp">
            <div className="csd-content">
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Job Summary :</h1>
                  <p style={{ textAlign: "justify" }}>
                    As a Finance Manager with 5 years of experience, you will
                    play a crucial role in overseeing the financial operations
                    and strategies of the organization. You will be responsible
                    for managing and optimizing financial resources, providing
                    financial analysis and reporting, and ensuring compliance
                    with financial regulations and policies. Additionally, you
                    will collaborate with cross-functional teams to support
                    decision-making processes and contribute to the overall
                    financial success of the company.
                  </p>

                  <img
                    className="my-4"
                    src="assets/images/case/1.jpg"
                    alt="Case image"
                  />
                </div>
              </div>
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Key Responsibilities:</h1>
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Financial Planning and Analysis: Develop and implement
                      financial strategies, plans, and budgets in alignment with
                      organizational goals. Conduct financial forecasting,
                      budgeting, and variance analysis to support
                      decision-making and resource allocation.Monitor and
                      analyze key financial metrics, identify trends, and
                      provide insights and recommendations to senior management.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Financial Reporting and Compliance: Prepare accurate and
                      timely financial statements, including income statements,
                      balance sheets, and cash flow statements.Ensure compliance
                      with financial regulations, accounting principles, and
                      internal policies.Coordinate external audits and provide
                      necessary documentation and support.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Cash Flow Management: Monitor cash flow and liquidity
                      positions, analyze cash flow projections, and recommend
                      strategies to optimize working capital.Manage
                      relationships with financial institutions, including
                      banking activities, credit facilities, and cash management
                      solutions.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Cost Management and Efficiency: Identify cost-saving
                      opportunities, analyze cost drivers, and implement
                      strategies to improve operational efficiency.Conduct
                      financial evaluations of projects, investments, and
                      business initiatives to assess their financial viability
                      and return on investment.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Team Leadership and Development: Lead and manage a team of
                      finance professionals, providing guidance, mentorship, and
                      performance feedback.Foster a culture of continuous
                      learning and development within the finance department.
                      Collaborate with other departments and stakeholders to
                      ensure effective communication and cross-functional
                      coordination.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Qualifications:</h1>
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Bachelor's degree in finance, accounting, or a related
                      field; a Master's degree or professional certification
                      (e.g., CPA, CMA, CA, CA Inter) is a plus.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Minimum of 5 years of experience in financial management,
                      accounting, or related roles.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Solid understanding of financial principles, practices,
                      and regulations.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Proficiency in financial analysis, financial modeling, and
                      forecasting techniques.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Strong knowledge of accounting software and financial
                      systems (e.g., SAP, Oracle, QuickBooks).
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Excellent analytical and problem-solving skills with keen
                      attention to detail.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Strong leadership and team management abilities.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Effective communication and presentation skills, both
                      written and verbal.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Ability to work collaboratively in a cross-functional
                      environment.
                    </span>
                  </p>
                </div>
              </div>
            </div>
            <div className="service-details-icon-box pt-3">
              <div className="service-page-title2">
                <p
                  style={{
                    textAlign: "justify",
                    fontSize: "15px",
                  }}
                >
                  <b>
                    If you meet these qualifications and are interested in this
                    exciting opportunity, please submit your application
                    including your resume.
                  </b>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default PortfolioDetails;
