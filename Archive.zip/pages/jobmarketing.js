import Breadcumb from "@/src/components/Breadcumb";
import Layout from "@/src/layout/Layout";
const PortfolioDetails = () => {
  return (
    <Layout>
      <Breadcumb
        pageName={"Marketing Consultant"}
        title={"Consulting Division"}
      />
      <div className="case-study-details">
        <div className="container">
          <div className="case-study-intro">
            <div className="row align-items-center">
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-thumb">
                  <img
                    src="assets/images/resource/portfolio-details.jpg"
                    alt="thumb"
                  />
                </div>
              </div>
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-info">
                  <div className="csd-title pt-30 mb-4">
                    <h3>Job Overviews</h3>
                  </div>
                  <ul>
                    <li>
                      <strong>Location</strong> <span>Ahmedabad </span>{" "}
                    </li>
                    <li>
                      <strong>Job Title</strong>{" "}
                      <span>Marketing Consultant</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Hours </strong>{" "}
                      <span>8h / day (5 days working)</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Mail Your Resume </strong>{" "}
                      <span style={{ textTransform: "lowercase" }}>
                        hr@codup.tech
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="case-study-intro upp">
            <div className="csd-content">
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Job Summary :</h1>
                  <p style={{ textAlign: "justify" }}>
                    Our company is seeking a skilled Marketing Consultant to
                    join our team. As a Marketing Consultant, you will be
                    responsible for developing and implementing marketing
                    strategies to increase our client base and enhance brand
                    awareness. You will work closely with clients to understand
                    their business objectives and provide tailored marketing
                    solutions. The ideal candidate will have extensive
                    experience in marketing and a proven track record of success
                    in driving business growth.
                  </p>

                  <img
                    className="my-4"
                    src="assets/images/case/1.jpg"
                    alt="Case image"
                  />
                </div>
              </div>
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Key Responsibilities:</h1>
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Collaborate with clients to identify marketing goals and
                      develop strategies to achieve them.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Conduct market research to identify trends and
                      opportunities for growth.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Develop and implement effective marketing initiatives to
                      increase brand awareness and drive sales.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Create engaging content for marketing materials, including
                      social media, website, and email campaigns.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Analyze campaign data to measure success and make ongoing
                      improvements.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Stay up-to-date with emerging marketing trends and
                      technologies to ensure our clients are ahead of the curve.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Build and maintain strong relationships with clients to
                      ensure ongoing success and satisfaction.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Conduct market research to gather data and insights on
                      customer preferences, market trends, and competitor
                      analysis. They use this information to identify
                      opportunities and make informed recommendations to improve
                      marketing effectiveness.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Assist in developing and refining a brand's identity and
                      positioning in the market. They help clients establish a
                      unique value proposition, create brand guideline.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Designing and executing marketing campaigns. They develop
                      campaign strategies, identify appropriate channels and
                      tactics, create content and creative assets, and monitor
                      campaign performance to ensure the desired outcomes are
                      achieved.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Focus on digital marketing strategies. They help clients
                      with website optimization, search engine optimization
                      (SEO), social media marketing, email marketing, content
                      marketing, paid advertising, and other digital marketing
                      initiatives.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Use data analysis tools and techniques to measure
                      marketing campaign performance, track key performance
                      indicators (KPIs), and provide insights to optimize
                      marketing efforts. They interpret data, identify trends,
                      and make data-driven recommendations to improve marketing
                      outcomes.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Qualifications:</h1>
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Bachelor's degree in marketing, communications, or a
                      related field.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      3-5 years of experience in marketing, with a focus on
                      strategy development and implementation.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Strong understanding of market research and analysis.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Excellent communication skills, both written and verbal.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Expertise in digital marketing, including social media,
                      email marketing, and content creation.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Ability to work independently and collaboratively in a
                      fast-paced, deadline-driven environment.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Demonstrated track record of success in driving business
                      growth through marketing initiatives.
                    </span>
                  </p>
                </div>
              </div>
            </div>
            <div className="service-details-icon-box pt-3">
              <div className="service-page-title2">
                <p
                  style={{
                    textAlign: "justify",
                    fontSize: "15px",
                  }}
                >
                  <b>
                    If you meet these qualifications and are interested in this
                    exciting opportunity, please submit your application
                    including your resume.
                  </b>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default PortfolioDetails;
