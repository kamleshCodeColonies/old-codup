import Breadcumb from "@/src/components/Breadcumb";
import Layout from "@/src/layout/Layout";
const PortfolioDetails = () => {
  return (
    <Layout>
      <Breadcumb
        pageName={"Legal and Regulatory Compliance "}
        title={"Optimization Consulting"}
      />
      <div className="case-study-details">
        <div className="container">
          <div className="case-study-intro">
            <div className="row align-items-center">
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-thumb">
                  <img
                    src="assets/images/resource/portfolio-details.jpg"
                    alt="thumb"
                  />
                </div>
              </div>
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-info">
                  <div className="csd-title pt-30 mb-4"></div>
                  <ul>
                    <li>
                      <strong>Case Study Title</strong>{" "}
                      <span>
                        Ensuring Regulatory Compliance: Legal and Compliance
                        Consulting for ABC Tech Solutions{" "}
                      </span>{" "}
                    </li>
                    <li>
                      <strong>Category</strong>{" "}
                      <span>Legal and Compliance Consulting</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Consulting Services </strong>{" "}
                      <span>Legal and Regulatory Compliance </span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Collaboration </strong> <span>Retainership</span>{" "}
                    </li>
                    {/* <li className="hr-4">
                      <strong>Completed </strong> <span>01 March, 2023</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Skills </strong>{" "}
                      <span>Photoshop / Illustrator</span>{" "}
                    </li> */}
                  </ul>
                  {/* <div className="share-text">
                    <h4>Share:</h4>
                  </div> */}
                  {/* <div className="csd-social-icon">
                    <ul>
                      <li>
                        <a href="#">
                          <i className="fab fa-facebook-f" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-twitter" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-pinterest" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-linkedin-in" />
                        </a>
                      </li>
                    </ul>
                  </div> */}
                </div>
              </div>
            </div>
          </div>
          <div className="case-study-intro upp">
            <div className="csd-content">
              {/* <div className="csd-title pb-10">
                <h2>
                  Revitalizing your operations with cutting-edge solutions -
                  Codup's expertise at your service
                </h2>
              </div> */}
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Background :</h1>
                  <p style={{ textAlign: "justify" }}>
                    ABC Tech Solutions, a rapidly growing software and IT
                    company, recognized the importance of adhering to legal and
                    regulatory requirements to safeguard their operations,
                    protect sensitive data, and maintain customer trust. Seeking
                    expert guidance, they engaged Codup for legal and compliance
                    consulting services to ensure full compliance with
                    applicable laws and regulations in the software and IT
                    industry.
                  </p>

                  <img
                    className="my-4"
                    src="assets/images/case/1.jpg"
                    alt="Case image"
                  />
                </div>
              </div>
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Objectives:</h1>
                  {/* <p>The main challenges the software startup faced were:</p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Assess the current legal and compliance landscape within
                      ABC Tech Solutions.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Identify potential areas of non-compliance and associated
                      risks.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Develop and implement effective strategies and measures to
                      achieve regulatory compliance.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Establish robust data protection and privacy practices.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Ensure proper handling and management of intellectual
                      property rights.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Enhance internal policies and procedures to align with
                      legal and regulatory requirements.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Provide ongoing guidance and support to maintain
                      compliance in a rapidly evolving regulatory environment.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Approach:</h1>
                  {/* <p>
                    The Codup's team worked closely with the software startup to
                    identify the underlying problems and develop a solution that
                    met their specific needs.
                  </p> */}
                  {/* <p>Solution involved the following steps:</p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Conducted a comprehensive legal and compliance audit to
                      assess the current state of ABC Tech Solutions'
                      operations, policies, and practices.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Identified gaps and areas of non-compliance with relevant
                      laws, regulations, and industry standards.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Collaborated with ABC Tech Solutions' legal team to
                      understand their specific legal and compliance
                      requirements.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Developed a tailored legal and compliance framework,
                      including policies, procedures, and guidelines.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Assisted in the implementation and enforcement of data
                      protection and privacy measures, including compliance with
                      GDPR, CCPA, and other applicable regulations.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Provided guidance on intellectual property management,
                      including patent filings, copyright protection, and trade
                      secret management.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Conducted employee training sessions to raise awareness of
                      legal and compliance obligations and foster a culture of
                      compliance.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Offered ongoing monitoring and support to address emerging
                      legal and regulatory changes.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Assisted in the development and review of contracts,
                      agreements, and other legal documents to ensure compliance
                      and mitigate legal risks.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Provided timely updates on new regulations and changes
                      impacting the software and IT industry.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Results:</h1>
                  {/* <p>
                    Codup's solutions helped the software startup in achieving
                    the following outcomes:
                  </p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Achieved full compliance with applicable laws,
                      regulations, and industry standards, reducing the risk of
                      legal issues and penalties for ABC Tech Solutions.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Strengthened data protection and privacy practices,
                      ensuring the proper handling and safeguarding of customer
                      and employee data.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Enhanced intellectual property management, protecting ABC
                      Tech Solutions' innovative ideas, technologies, and
                      software solutions.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Established robust internal policies and procedures that
                      aligned with legal and regulatory requirements, promoting
                      a culture of compliance within the organization.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Increased awareness and understanding of legal and
                      compliance obligations among employees through
                      comprehensive training sessions.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Maintained proactive compliance with evolving legal and
                      regulatory changes through ongoing monitoring and updates.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Mitigated legal risks associated with contracts,
                      agreements, and other legal documents by ensuring
                      compliance and minimizing potential liabilities.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Positioned ABC Tech Solutions as a trusted and compliant
                      partner for their clients, enhancing their reputation and
                      competitive edge in the software and IT industry.
                    </span>
                  </p>
                </div>
              </div>
              <div className="service-details-icon-box pt-1">
                <div className="service-page-title2">
                  <h1>Conclusion:</h1>
                  <p style={{ textAlign: "justify" }}>
                    Through the partnership with Codup for legal and compliance
                    consulting services, ABC Tech Solutions successfully
                    achieved and maintained regulatory compliance, safeguarding
                    their operations, protecting sensitive data, and mitigating
                    legal risks. The comprehensive legal and compliance
                    framework implemented with the guidance of Codup ensured
                    adherence to relevant laws, regulations, and industry
                    standards. ABC Tech Solutions can now focus on their core
                    business activities with confidence, knowing that they are
                    compliant with legal and regulatory requirements in the
                    software and IT industry.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default PortfolioDetails;
