import Breadcumb from "@/src/components/Breadcumb";
import Layout from "@/src/layout/Layout";
const PortfolioDetails = () => {
  return (
    <Layout>
      <Breadcumb
        pageName={"Talent Acquisition and Management"}
        title={"Functional Consulting"}
      />
      <div className="case-study-details">
        <div className="container">
          <div className="case-study-intro">
            <div className="row align-items-center">
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-thumb">
                  <img
                    src="assets/images/resource/portfolio-details.jpg"
                    alt="thumb"
                  />
                </div>
              </div>
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-info">
                  <div className="csd-title pt-30 mb-4"></div>
                  <ul>
                    <li>
                      <strong>Case Study Title</strong>{" "}
                      <span>
                        Building a High-Performance Workforce: Strategic HR
                        Consulting for XYZ Tech Solutions{" "}
                      </span>{" "}
                    </li>
                    <li>
                      <strong>Category</strong>{" "}
                      <span>Human Resources Consulting</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Consulting Services </strong>{" "}
                      <span>Talent Acquisition and Management</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Collaboration </strong>{" "}
                      <span>Project-based Engagement</span>{" "}
                    </li>
                    {/* <li className="hr-4">
                      <strong>Completed </strong> <span>01 March, 2023</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Skills </strong>{" "}
                      <span>Photoshop / Illustrator</span>{" "}
                    </li> */}
                  </ul>
                  {/* <div className="share-text">
                    <h4>Share:</h4>
                  </div> */}
                  {/* <div className="csd-social-icon">
                    <ul>
                      <li>
                        <a href="#">
                          <i className="fab fa-facebook-f" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-twitter" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-pinterest" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-linkedin-in" />
                        </a>
                      </li>
                    </ul>
                  </div> */}
                </div>
              </div>
            </div>
          </div>
          <div className="case-study-intro upp">
            <div className="csd-content">
              {/* <div className="csd-title pb-10">
                <h2>
                  Revitalizing your operations with cutting-edge solutions -
                  Codup's expertise at your service
                </h2>
              </div> */}
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Background :</h1>
                  <p style={{ textAlign: "justify" }}>
                    XYZ Tech Solutions, a leading software development company,
                    recognized the need to optimize their human resources
                    practices to attract, retain, and develop top talent in the
                    competitive IT industry. Seeking expertise in strategic HR
                    consulting, they partnered with Codup to enhance their
                    talent acquisition and management processes. The goal was to
                    build a high-performance workforce, align HR strategies with
                    business objectives, and create a positive and engaging work
                    culture.
                  </p>

                  <img
                    className="my-4"
                    src="assets/images/case/1.jpg"
                    alt="Case image"
                  />
                </div>
              </div>
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Objectives:</h1>
                  {/* <p>The main challenges the software startup faced were:</p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Assess XYZ Tech Solutions' current HR practices and
                      identify areas for improvement.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Develop a strategic talent acquisition and management plan
                      to attract, hire, and retain skilled professionals.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Streamline performance management processes and establish
                      clear performance metrics.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Enhance employee engagement initiatives and foster a
                      positive work environment.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Identify and address skill gaps through training and
                      development programs.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Provide guidance on HR policies and compliance with
                      relevant labor laws and regulations.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Offer ongoing support to HR teams for effective
                      implementation of recommended strategies.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Approach:</h1>
                  {/* <p>
                    The Codup's team worked closely with the software startup to
                    identify the underlying problems and develop a solution that
                    met their specific needs.
                  </p> */}
                  {/* <p>Solution involved the following steps:</p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Conducted a comprehensive analysis of XYZ Tech Solutions'
                      existing HR practices, policies, and procedures.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Collaborated with key stakeholders to understand the
                      company's business objectives, growth plans, and HR
                      challenges.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Conducted a talent needs assessment to identify critical
                      roles and competencies required for success.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Developed a tailored talent acquisition strategy,
                      including sourcing strategies, candidate assessment
                      methodologies, and employer branding initiatives.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Assisted in the recruitment and selection process by
                      providing guidance on job descriptions, candidate
                      screening, and interviewing techniques.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Developed performance management frameworks, including
                      clear performance metrics, goal-setting processes, and
                      performance review systems.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Assessed the company's employee engagement initiatives and
                      recommended strategies to enhance employee satisfaction
                      and retention.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Identified skill gaps and developed customized training
                      and development programs to address them.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Provided guidance on HR policies and compliance with labor
                      laws and regulations, ensuring fair and ethical practices.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Offered ongoing support to the HR team through regular
                      check-ins, training sessions, and guidance on HR-related
                      challenges.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Monitored the implementation of recommended strategies and
                      provided feedback for continuous improvement.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Results:</h1>
                  {/* <p>
                    Codup's solutions helped the software startup in achieving
                    the following outcomes:
                  </p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      XYZ Tech Solutions improved their talent acquisition
                      process, attracting and hiring top-quality professionals
                      to meet their business needs.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Enhanced performance management processes led to clearer
                      performance expectations and improved individual and team
                      performance.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Employee engagement initiatives fostered a positive work
                      environment, resulting in increased employee satisfaction
                      and retention.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Addressing skill gaps through targeted training and
                      development programs improved employee competencies and
                      contributed to overall organizational growth.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Streamlined HR policies and compliance with labor laws and
                      regulations ensured fair and ethical practices within the
                      organization.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      HR teams were equipped with the necessary knowledge and
                      skills to effectively implement HR strategies and drive
                      positive change.
                    </span>
                  </p>
                </div>
              </div>
              <div className="service-details-icon-box pt-1">
                <div className="service-page-title2">
                  <h1>Conclusion:</h1>
                  <p style={{ textAlign: "justify" }}>
                    By partnering with Codup for strategic HR consulting, XYZ
                    Tech Solutions successfully optimized their human resources
                    practices, creating a high-performance workforce and a
                    positive work culture. Through a tailored talent acquisition
                    and management plan, enhanced performance management
                    processes, employee engagement initiatives, and targeted
                    training programs, they attracted top talent, improved
                    employee satisfaction, and drove organizational growth. XYZ
                    Tech Solutions can now effectively manage their human
                    resources, align HR strategies with business objectives, and
                    stay ahead in the competitive software and IT industry.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default PortfolioDetails;
