import Breadcumb from "@/src/components/Breadcumb";
import Layout from "@/src/layout/Layout";
const PortfolioDetails = () => {
  return (
    <Layout>
      <Breadcumb pageName={"Software Developer"} title={"IT Division"} />
      <div className="case-study-details">
        <div className="container">
          <div className="case-study-intro">
            <div className="row align-items-center">
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-thumb">
                  <img
                    src="assets/images/resource/portfolio-details.jpg"
                    alt="thumb"
                  />
                </div>
              </div>
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-info">
                  <div className="csd-title pt-30 mb-4">
                    <h3>Job Overviews</h3>
                  </div>
                  <ul>
                    <li>
                      <strong>Location</strong> <span>Ahmedabad </span>{" "}
                    </li>
                    <li>
                      <strong>Job Title</strong> <span>Software Developer</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Hours </strong>{" "}
                      <span>8h / day (5 days working)</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Mail Your Resume </strong>{" "}
                      <span style={{ textTransform: "lowercase" }}>
                        hr@codup.tech
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="case-study-intro upp">
            <div className="csd-content">
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Job Summary :</h1>
                  <p style={{ textAlign: "justify" }}>
                    We looking for a talented and motivated software developer
                    to join our company. As a software developer, you will work
                    closely with our team of developers to design, develop, and
                    maintain high-quality software applications. You will be
                    responsible for creating clean and efficient code that meets
                    project requirements and adheres to coding standards. You
                    will have the opportunity to work with cutting-edge
                    technology and contribute to the development of innovative
                    software solutions that help solve real-world problems.
                  </p>

                  <img
                    className="my-4"
                    src="assets/images/case/1.jpg"
                    alt="Case image"
                  />
                </div>
              </div>
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Key Responsibilities:</h1>
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Design and develop software applications in collaboration
                      with the development team.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Write clean, efficient, and maintainable code that meets
                      project requirements and coding standards.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span> Troubleshoot and debug software issues. </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span> Test and verify software functionality.</span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Collaborate with cross-functional teams to ensure project
                      success.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Provide technical expertise and guidance to team members.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Analysis and Requirements Gathering: Collaborating with
                      stakeholders to understand their software requirements,
                      identifying key functionalities, and documenting
                      specifications.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Software Design: Creating a high-level design or
                      architecture for the software solution, including defining
                      data structures, algorithms, and user interfaces.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Programming: Writing clean, efficient, and reliable code
                      using programming languages and frameworks suitable for
                      the project, following industry best practices and coding
                      standards.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Testing and Debugging: Conducting unit tests, integration
                      tests, and debugging to identify and fix software defects
                      or issues, ensuring the software performs as expected.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Documentation: Creating technical documentation, including
                      system design, user manuals, and code comments, to
                      facilitate understanding and future maintenance of the
                      software.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Qualifications:</h1>
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Bachelor's degree in Computer Science or related field.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      At least 3 years of experience in software development.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Proficiency in programming languages such as Java, C++, or
                      Python.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Familiarity with software development tools, such as Git,
                      JIRA, and Jenkins.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Experience with database technologies, such as SQL and
                      Oracle.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span> Strong problem-solving and analytical skills.</span>
                  </p>
                </div>
              </div>
            </div>
            <div className="service-details-icon-box pt-3">
              <div className="service-page-title2">
                <p
                  style={{
                    textAlign: "justify",
                    fontSize: "15px",
                  }}
                >
                  <b>
                    If you meet these qualifications and are interested in this
                    exciting opportunity, please submit your application
                    including your resume.
                  </b>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default PortfolioDetails;
