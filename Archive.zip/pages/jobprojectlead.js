import Breadcumb from "@/src/components/Breadcumb";
import Layout from "@/src/layout/Layout";
const PortfolioDetails = () => {
  return (
    <Layout>
      <Breadcumb pageName={"Project Lead"} title={"IT Division"} />
      <div className="case-study-details">
        <div className="container">
          <div className="case-study-intro">
            <div className="row align-items-center">
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-thumb">
                  <img
                    src="assets/images/resource/portfolio-details.jpg"
                    alt="thumb"
                  />
                </div>
              </div>
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-info">
                  <div className="csd-title pt-30 mb-4">
                    <h3>Job Overviews</h3>
                  </div>
                  <ul>
                    <li>
                      <strong>Location</strong> <span>Ahmedabad </span>{" "}
                    </li>
                    <li>
                      <strong>Job Title</strong> <span>Project Lead</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Hours </strong>{" "}
                      <span>8h / day (5 days working)</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Mail Your Resume </strong>{" "}
                      <span style={{ textTransform: "lowercase" }}>
                        hr@codup.tech
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="case-study-intro upp">
            <div className="csd-content">
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Job Summary :</h1>
                  <p style={{ textAlign: "justify" }}>
                    We are looking for a creative, reliable, and
                    results-oriented individual to join our team as a Project
                    Lead. In this role, you will be responsible for leading the
                    design and development of large-scale projects, creating
                    project plans, coordinating resources, overseeing day-to-day
                    activities, and driving project performance. you will be
                    part of a dynamic and driven team who are dedicated to
                    pushing the boundaries of technology. We actively foster a
                    collaborative working environment and encourage open
                    communication between our employees.
                  </p>

                  <img
                    className="my-4"
                    src="assets/images/case/1.jpg"
                    alt="Case image"
                  />
                </div>
              </div>
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Key Responsibilities:</h1>
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Project Planning: The Project Lead is responsible for
                      developing a comprehensive project plan, including
                      defining project goals, scope, objectives, deliverables,
                      and timelines. They work closely with stakeholders to
                      understand requirements and create an effective plan.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Team Management: The Project Lead manages the project
                      team, which may include assigning tasks, coordinating
                      resources, and providing guidance and support to team
                      members. They ensure that the team is motivated,
                      productive, and working towards project goals.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Communication and Stakeholder Management: The Project Lead
                      serves as the primary point of contact for project
                      communication. They facilitate effective communication
                      among team members, stakeholders, and project sponsors.
                      They also manage stakeholder expectations and provide
                      regular project updates.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Risk Management: The Project Lead identifies and assesses
                      project risks and develops strategies to mitigate them.
                      They proactively identify potential roadblocks and issues
                      that may impact the project's success and take appropriate
                      actions to minimize their impact.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Budget and Resource Management: The Project Lead is
                      responsible for managing project budgets and resources
                      effectively. They track project expenses, monitor resource
                      utilization, and ensure that the project is delivered
                      within the allocated budget and resource constraints.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Quality Assurance: The Project Lead ensures that project
                      deliverables meet the required quality standards. They
                      establish quality control processes, conduct regular
                      reviews, and implement corrective actions as needed to
                      maintain project quality.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Change Management: The Project Lead manages project
                      changes and their impact on scope, schedule, and
                      resources. They assess change requests, evaluate their
                      feasibility, and make decisions regarding their
                      implementation. They also communicate changes to
                      stakeholders and ensure proper documentation.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Qualifications:</h1>
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      3 -5 years of experience leading development team.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Exceptional organizational and multitasking skills.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Proven success in developing projects on time and on
                      budget.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Proficiency in project management tools and techniques.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Outstanding communication and interpersonal skills.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Ability to work independently or collaborate effectively
                      with other teams.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Problem-solving mentality and creative approach to
                      developing solutions.
                    </span>
                  </p>
                </div>
              </div>
            </div>
            <div className="service-details-icon-box pt-3">
              <div className="service-page-title2">
                <p
                  style={{
                    textAlign: "justify",
                    fontSize: "15px",
                  }}
                >
                  <b>
                    If you meet these qualifications and are interested in this
                    exciting opportunity, please submit your application
                    including your resume.
                  </b>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default PortfolioDetails;
