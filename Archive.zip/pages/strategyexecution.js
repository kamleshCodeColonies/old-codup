import Breadcumb from "@/src/components/Breadcumb";
import Layout from "@/src/layout/Layout";
const PortfolioDetails = () => {
  return (
    <Layout>
      <Breadcumb
        pageName={" Strategy & Execution"}
        title={"Strategic Consulting"}
      />
      <div className="case-study-details">
        <div className="container">
          <div className="case-study-intro">
            <div className="row align-items-center">
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-thumb">
                  <img
                    src="assets/images/resource/portfolio-details.jpg"
                    alt="thumb"
                  />
                </div>
              </div>
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-info">
                  <div className="csd-title pt-30 mb-4"></div>
                  <ul>
                    <li>
                      <strong>Case Study Title</strong>{" "}
                      <span>
                        Driving Digital Transformation for Retail Company ABC{" "}
                      </span>{" "}
                    </li>
                    <li>
                      <strong>Category</strong>{" "}
                      <span>Strategic Consulting</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Consulting Services </strong>{" "}
                      <span>Strategy & Execution </span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Collaboration </strong> <span>Project-Based</span>{" "}
                    </li>
                    {/* <li className="hr-4">
                      <strong>Completed </strong> <span>01 March, 2023</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Skills </strong>{" "}
                      <span>Photoshop / Illustrator</span>{" "}
                    </li> */}
                  </ul>
                  {/* <div className="share-text">
                    <h4>Share:</h4>
                  </div> */}
                  {/* <div className="csd-social-icon">
                    <ul>
                      <li>
                        <a href="#">
                          <i className="fab fa-facebook-f" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-twitter" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-pinterest" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-linkedin-in" />
                        </a>
                      </li>
                    </ul>
                  </div> */}
                </div>
              </div>
            </div>
          </div>
          <div className="case-study-intro upp">
            <div className="csd-content">
              {/* <div className="csd-title pb-10">
                <h2>
                  Revitalizing your operations with cutting-edge solutions -
                  Codup's expertise at your service
                </h2>
              </div> */}
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Background :</h1>
                  <p style={{ textAlign: "justify" }}>
                    Retail Company ABC, a well-established player in the retail
                    industry, recognized the need to embrace digital
                    technologies to stay competitive in the market. They engaged
                    Codup to lead their digital transformation initiatives and
                    drive growth through innovation.
                  </p>

                  <img
                    className="my-4"
                    src="assets/images/case/1.jpg"
                    alt="Case image"
                  />
                </div>
              </div>
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Objectives:</h1>
                  {/* <p>The main challenges the software startup faced were:</p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Develop a digital strategy to enhance the customer
                      experience and increase online sales.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Optimize business operations by leveraging technology and
                      automation.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Implement data-driven decision-making processes for
                      improved insights and agility.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Establish a strong online presence and omnichannel
                      capabilities.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Approach:</h1>
                  {/* <p>
                    The Codup's team worked closely with the software startup to
                    identify the underlying problems and develop a solution that
                    met their specific needs.
                  </p> */}
                  {/* <p>Solution involved the following steps:</p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Conducted a comprehensive assessment of the company's
                      current digital landscape and market trends.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Defined a digital roadmap aligned with the company's goals
                      and industry best practices.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Collaborated with cross-functional teams to identify
                      opportunities for digital integration and process
                      optimization.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Implemented scalable e-commerce solutions and improved
                      website usability for enhanced customer experience.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Leveraged data analytics and business intelligence tools
                      to enable data-driven decision-making.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Developed digital marketing strategies to drive targeted
                      traffic and increase online conversions.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Provided training and support to ensure a smooth
                      transition and adoption of digital technologies.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Results:</h1>
                  {/* <p>
                    Codup's solutions helped the software startup in achieving
                    the following outcomes:
                  </p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Increased online sales by 50%, surpassing industry
                      benchmarks.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Improved customer engagement and satisfaction through
                      personalized digital experiences.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Optimized supply chain management, resulting in a 25%
                      reduction in lead time and improved inventory management.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Enhanced decision-making capabilities by leveraging
                      real-time data and analytics.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Achieved a 30% growth in customer acquisition through
                      targeted digital marketing campaigns.
                    </span>
                  </p>
                </div>
              </div>
              <div className="service-details-icon-box pt-1">
                <div className="service-page-title2">
                  <h1>Conclusion:</h1>
                  <p style={{ textAlign: "justify" }}>
                    Through strategic digital transformation consulting, Codup
                    empowered Retail Company ABC to successfully adapt to the
                    evolving digital landscape. The collaboration resulted in
                    improved customer experiences, increased sales, and
                    optimized business operations. Retail Company ABC emerged as
                    a digitally-enabled organization, well-positioned for
                    sustainable growth in the competitive retail industry.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default PortfolioDetails;
