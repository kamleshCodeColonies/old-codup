import Breadcumb from "@/src/components/Breadcumb";
import Layout from "@/src/layout/Layout";
const PortfolioDetails = () => {
  return (
    <Layout>
      <Breadcumb pageName={"Sr. Software Developer"} title={"IT Division"} />
      <div className="case-study-details">
        <div className="container">
          <div className="case-study-intro">
            <div className="row align-items-center">
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-thumb">
                  <img
                    src="assets/images/resource/portfolio-details.jpg"
                    alt="thumb"
                  />
                </div>
              </div>
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-info">
                  <div className="csd-title pt-30 mb-4">
                    <h3>Job Overviews</h3>
                  </div>
                  <ul>
                    <li>
                      <strong>Location</strong> <span>Ahmedabad </span>{" "}
                    </li>
                    <li>
                      <strong>Job Title</strong>{" "}
                      <span>Sr. Software Developer</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Hours </strong>{" "}
                      <span>8h / day (5 days working)</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Mail Your Resume </strong>{" "}
                      <span style={{ textTransform: "lowercase" }}>
                        hr@codup.tech
                      </span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="case-study-intro upp">
            <div className="csd-content">
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Job Summary :</h1>
                  <p style={{ textAlign: "justify" }}>
                    We are looking for a highly skilled Senior Software
                    Developer to join our team. As a Senior Software Developer,
                    you will be responsible for developing and maintaining
                    software products that meet customer needs. You will be
                    working on cutting-edge technologies and solutions, and you
                    will play a key role in the design, development, testing,
                    and deployment of software products.
                  </p>

                  <img
                    className="my-4"
                    src="assets/images/case/1.jpg"
                    alt="Case image"
                  />
                </div>
              </div>
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Key Responsibilities:</h1>
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Participate in the design, development, and maintenance of
                      software systems.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Write clean, efficient, and well-documented code.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Collaborate with cross-functional teams to ideate software
                      solutions.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Ensure software quality through testing, debugging, and
                      troubleshooting.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Create technical specifications and system architecture
                      documentation.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Mentor and provide guidance to junior developers.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Keep up-to-date with emerging trends and technologies in
                      software development.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      As a senior developer, you will be involved in designing,
                      coding, testing, and debugging complex software
                      applications.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      You will be responsible for writing high-quality,
                      efficient, and maintainable code while following best
                      practices and coding standards.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      As a senior member of the team, you are expected to
                      provide technical leadership and guidance to junior
                      developers. This involves sharing your expertise,
                      mentoring team members, and conducting code reviews to
                      ensure the overall quality and consistency of the
                      codebase.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      You will collaborate with other stakeholders, such as
                      software architects or product managers, to define the
                      overall system architecture, making decisions about
                      frameworks, libraries, and technologies to be used.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Responsible for managing projects or specific workstreams.
                      This includes planning, organizing, and prioritizing
                      tasks, estimating effort, and coordinating with other team
                      members or departments to ensure timely and successful
                      project completion.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      As technology evolves rapidly, senior developers are
                      responsible for staying up-to-date with the latest
                      industry trends, tools, and practices.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Alongside writing new code, senior developers are
                      responsible for maintaining and refactoring existing
                      codebases.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Qualifications:</h1>
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      3-5 years of experience in software development.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Proficiency in programming languages such as Java, C#, or
                      Python.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Experience with software development methodologies such as
                      Agile and Scrum.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span> Strong analytical and problem-solving skills.</span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span> Excellent teamwork and communication skills.</span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Bachelor's or Master's degree in Computer Science,
                      Engineering, or a related field.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Experience with cloud technologies such as AWS or Azure is
                      a plus.
                    </span>
                  </p>
                </div>
              </div>
            </div>
            <div className="service-details-icon-box pt-3">
              <div className="service-page-title2">
                <p
                  style={{
                    textAlign: "justify",
                    fontSize: "15px",
                  }}
                >
                  <b>
                    If you meet these qualifications and are interested in this
                    exciting opportunity, please submit your application
                    including your resume.
                  </b>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default PortfolioDetails;
