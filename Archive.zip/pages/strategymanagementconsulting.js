import Breadcumb from "@/src/components/Breadcumb";
import Layout from "@/src/layout/Layout";
const PortfolioDetails = () => {
  return (
    <Layout>
      <Breadcumb
        pageName={"Strategy & Management Consulting"}
        title={"Strategic Consulting"}
      />
      <div className="case-study-details">
        <div className="container">
          <div className="case-study-intro">
            <div className="row align-items-center">
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-thumb">
                  <img
                    src="assets/images/resource/portfolio-details.jpg"
                    alt="thumb"
                  />
                </div>
              </div>
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-info">
                  <div className="csd-title pt-30 mb-4"></div>
                  <ul>
                    <li>
                      <strong>Case Study Title</strong>{" "}
                      <span>
                        Driving Organizational Transformation through Strategic
                        Business{" "}
                      </span>{" "}
                    </li>
                    <li>
                      <strong>Category</strong>{" "}
                      <span>Strategic Consulting</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Consulting Services </strong>{" "}
                      <span>Strategy & Management Consulting </span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Collaboration </strong> <span>Retainership</span>{" "}
                    </li>
                    {/* <li className="hr-4">
                      <strong>Completed </strong> <span>01 March, 2023</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Skills </strong>{" "}
                      <span>Photoshop / Illustrator</span>{" "}
                    </li> */}
                  </ul>
                  {/* <div className="share-text">
                    <h4>Share:</h4>
                  </div> */}
                  {/* <div className="csd-social-icon">
                    <ul>
                      <li>
                        <a href="#">
                          <i className="fab fa-facebook-f" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-twitter" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-pinterest" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-linkedin-in" />
                        </a>
                      </li>
                    </ul>
                  </div> */}
                </div>
              </div>
            </div>
          </div>
          <div className="case-study-intro upp">
            <div className="csd-content">
              {/* <div className="csd-title pb-10">
                <h2>
                  Revitalizing your operations with cutting-edge solutions -
                  Codup's expertise at your service
                </h2>
              </div> */}
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Background :</h1>
                  <p style={{ textAlign: "justify" }}>
                    XYZ Tech Solutions, a leading software development company,
                    recognized the need for strategic guidance and
                    transformational changes to stay competitive in the rapidly
                    evolving technology landscape. They engaged Codup for
                    management consulting services to help them navigate through
                    the challenges and drive organizational transformation.
                  </p>

                  <img
                    className="my-4"
                    src="assets/images/case/1.jpg"
                    alt="Case image"
                  />
                </div>
              </div>
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Objectives:</h1>
                  {/* <p>The main challenges the software startup faced were:</p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Develop a comprehensive strategic roadmap to align
                      business goals with market opportunities.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Identify key areas for operational improvement and
                      efficiency enhancement.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Enhance leadership capabilities and cultivate a culture of
                      innovation and continuous improvement.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Optimize resource allocation and portfolio management to
                      drive growth and profitability.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Implement effective change management strategies to ensure
                      smooth adoption of new initiatives.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Approach:</h1>
                  {/* <p>
                    The Codup's team worked closely with the software startup to
                    identify the underlying problems and develop a solution that
                    met their specific needs.
                  </p> */}
                  {/* <p>Solution involved the following steps:</p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Conducted a thorough analysis of XYZ Tech Solutions'
                      current business model, market positioning, and
                      competitive landscape.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Collaborated with key stakeholders to gain a deep
                      understanding of their goals, challenges, and vision for
                      the future.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Developed a tailored strategic roadmap, outlining
                      actionable steps to achieve long-term objectives and
                      address immediate needs.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Provided guidance on optimizing operational processes,
                      streamlining workflows, and improving resource
                      utilization.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Assessed leadership capabilities and implemented
                      leadership development programs to foster innovation and
                      drive cultural change.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Conducted organizational assessments to identify skills
                      gaps and recommended training and development initiatives.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Introduced portfolio management strategies to evaluate and
                      prioritize investments based on strategic alignment and
                      return on investment.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Implemented change management processes to ensure
                      successful adoption of new initiatives and minimize
                      resistance.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Results:</h1>
                  {/* <p>
                    Codup's solutions helped the software startup in achieving
                    the following outcomes:
                  </p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Aligned business strategies with market opportunities,
                      enabling XYZ Tech Solutions to adapt to changing customer
                      needs and industry trends.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Streamlined operational processes, resulting in increased
                      efficiency, reduced costs, and improved customer
                      satisfaction.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Developed strong leadership capabilities, empowering teams
                      to drive innovation, foster collaboration, and deliver
                      high-quality solutions.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Optimized resource allocation and portfolio management,
                      leading to improved project outcomes and higher
                      profitability.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Successfully managed organizational change, minimizing
                      disruptions and ensuring a smooth transition to new
                      initiatives.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Enhanced employee engagement and retention through
                      targeted training and development programs.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Strengthened XYZ Tech Solutions' competitive position in
                      the market, enabling them to capture new business
                      opportunities.
                    </span>
                  </p>
                </div>
              </div>
              <div className="service-details-icon-box pt-1">
                <div className="service-page-title2">
                  <h1>Conclusion:</h1>
                  <p style={{ textAlign: "justify" }}>
                    By partnering with Codup for management consulting services,
                    XYZ Tech Solutions underwent a transformative journey,
                    aligning their business strategies, optimizing operations,
                    and nurturing a culture of innovation. The strategic
                    guidance provided by Codup enabled XYZ Tech Solutions to
                    adapt to market changes, drive growth, and enhance their
                    competitive advantage. As a result, XYZ Tech Solutions
                    emerged as a leader in the software and IT industry,
                    delivering innovative solutions and achieving sustainable
                    business success.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default PortfolioDetails;
