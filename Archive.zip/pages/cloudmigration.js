import Breadcumb from "@/src/components/Breadcumb";
import Layout from "@/src/layout/Layout";
const PortfolioDetails = () => {
  return (
    <Layout>
      <Breadcumb
        pageName={"Cloud Migration "}
        title={"Optimization Consulting"}
      />
      <div className="case-study-details">
        <div className="container">
          <div className="case-study-intro">
            <div className="row align-items-center">
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-thumb">
                  <img
                    src="assets/images/resource/portfolio-details.jpg"
                    alt="thumb"
                  />
                </div>
              </div>
              <div className=" col-sm-12 col-md-6 col-lg-6">
                <div className="csd-info">
                  <div className="csd-title pt-30 mb-4"></div>
                  <ul>
                    <li>
                      <strong>Case Study Title</strong>{" "}
                      <span>
                        Enhancing Operational Efficiency through Cloud Migration{" "}
                      </span>{" "}
                    </li>
                    <li>
                      <strong>Category</strong>{" "}
                      <span>Optimization Consulting</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Consulting Services </strong>{" "}
                      <span>Cloud Migration </span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Collaboration </strong> <span>Project-based</span>{" "}
                    </li>
                    {/* <li className="hr-4">
                      <strong>Completed </strong> <span>01 March, 2023</span>{" "}
                    </li>
                    <li className="hr-4">
                      <strong>Skills </strong>{" "}
                      <span>Photoshop / Illustrator</span>{" "}
                    </li> */}
                  </ul>
                  {/* <div className="share-text">
                    <h4>Share:</h4>
                  </div> */}
                  {/* <div className="csd-social-icon">
                    <ul>
                      <li>
                        <a href="#">
                          <i className="fab fa-facebook-f" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-twitter" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-pinterest" />
                        </a>
                      </li>
                      <li>
                        <a href="#">
                          <i className="fab fa-linkedin-in" />
                        </a>
                      </li>
                    </ul>
                  </div> */}
                </div>
              </div>
            </div>
          </div>
          <div className="case-study-intro upp">
            <div className="csd-content">
              {/* <div className="csd-title pb-10">
                <h2>
                  Revitalizing your operations with cutting-edge solutions -
                  Codup's expertise at your service
                </h2>
              </div> */}
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Background :</h1>
                  <p style={{ textAlign: "justify" }}>
                    XYZ Software Solutions, a leading software development
                    company, was facing challenges with their on-premises
                    infrastructure, including limited scalability, high
                    maintenance costs, and inefficient resource allocation. They
                    partnered with Codup to migrate their applications and
                    systems to the cloud for improved operational efficiency and
                    agility.
                  </p>

                  <img
                    className="my-4"
                    src="assets/images/case/1.jpg"
                    alt="Case image"
                  />
                </div>
              </div>
              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Objectives:</h1>
                  {/* <p>The main challenges the software startup faced were:</p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Reduce infrastructure costs and eliminate the need for
                      extensive hardware investments.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Enhance scalability and flexibility to accommodate
                      business growth and changing demands.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Improve system performance and availability for seamless
                      user experience.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Strengthen data security and implement robust disaster
                      recovery measures.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Streamline application deployment and management
                      processes.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Approach:</h1>
                  {/* <p>
                    The Codup's team worked closely with the software startup to
                    identify the underlying problems and develop a solution that
                    met their specific needs.
                  </p> */}
                  {/* <p>Solution involved the following steps:</p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Conducted a comprehensive assessment of XYZ Software
                      Solutions' existing infrastructure, applications, and
                      business requirements.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Developed a tailored cloud migration strategy considering
                      factors such as application dependencies, data storage
                      needs, and compliance requirements.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Implemented a phased migration approach, prioritizing
                      critical applications and ensuring minimal disruption to
                      ongoing operations.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Leveraged industry-leading cloud platforms and services to
                      design a scalable and secure cloud architecture.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Migrated applications, databases, and data storage to the
                      cloud, ensuring data integrity and minimal downtime.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Implemented robust security measures, including data
                      encryption, access controls, and disaster recovery
                      mechanisms.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Provided training and support to XYZ Software Solutions'
                      IT team to effectively manage the cloud environment.
                    </span>
                  </p>
                </div>
              </div>

              <div className="service-details-icon-box">
                <div className="service-page-title2">
                  <h1>Results:</h1>
                  {/* <p>
                    Codup's solutions helped the software startup in achieving
                    the following outcomes:
                  </p> */}
                </div>
                <div className="widget-service-details-icon">
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Achieved a 40% reduction in infrastructure costs by
                      eliminating the need for on-premises hardware and
                      maintenance.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Improved scalability and flexibility, enabling XYZ
                      Software Solutions to handle increased workloads and
                      seasonal spikes without resource constraints.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Enhanced system performance and availability, resulting in
                      faster response times and improved user satisfaction.{" "}
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Strengthened data security with encryption, access
                      controls, and regular backups, ensuring compliance with
                      industry regulations.
                    </span>
                  </p>
                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Streamlined application deployment and management
                      processes, reducing time-to-market for new software
                      releases.
                    </span>
                  </p>

                  <p>
                    <i className="bi bi-check-lg" />{" "}
                    <span>
                      {" "}
                      Enabled seamless collaboration and remote access for
                      teams, facilitating productivity and efficient workflow.
                    </span>
                  </p>
                </div>
              </div>
              <div className="service-details-icon-box pt-1">
                <div className="service-page-title2">
                  <h1>Conclusion:</h1>
                  <p style={{ textAlign: "justify" }}>
                    By partnering with Codup for a strategic cloud migration
                    initiative, XYZ Software Solutions successfully improved
                    operational efficiency, reduced costs, and enhanced
                    scalability and security. The shift to the cloud allowed
                    them to focus on their core competencies while leveraging
                    cutting-edge technology and industry best practices. The
                    cloud migration empowered XYZ Software Solutions to stay
                    competitive, innovate faster, and deliver enhanced value to
                    their customers.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
};
export default PortfolioDetails;
